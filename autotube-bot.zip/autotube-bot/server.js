require("dotenv").config();
const express = require("express");
const cron = require("node-cron");
const fs = require("fs");
const path = require("path");

const { researchAndWrite } = require("./lib/research");
const { generateVoiceover } = require("./lib/voice");
const { generateImage } = require("./lib/visuals");
const { assembleVideo } = require("./lib/video");
const { getAuthUrl, saveTokenFromCode, hasToken, uploadVideo } = require("./lib/upload");

const app = express();
const DATA_DIR = process.env.DATA_DIR || "./data";
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

let lastRun = null;
let isRunning = false;
const log = [];
function pushLog(msg) {
  const line = `[${new Date().toISOString()}] ${msg}`;
  console.log(line);
  log.push(line);
  if (log.length > 200) log.shift();
}

/* ── THE FULL PIPELINE ── */
async function runPipeline() {
  if (isRunning) {
    pushLog("Skipped run — previous run still in progress.");
    return;
  }
  isRunning = true;
  const runId = Date.now();
  const workDir = path.join(DATA_DIR, `run-${runId}`);
  fs.mkdirSync(workDir, { recursive: true });

  try {
    pushLog("Step 1/5: Researching trends & writing script…");
    const plan = await researchAndWrite({ niche: process.env.NICHE });
    fs.writeFileSync(path.join(workDir, "plan.json"), JSON.stringify(plan, null, 2));

    pushLog(`Step 2/5: Generating voiceover for "${plan.title}"…`);
    const audioPath = path.join(workDir, "voice.mp3");
    await generateVoiceover(plan.script, audioPath);

    pushLog("Step 3/5: Generating scene visuals…");
    const imagePaths = [];
    for (let i = 0; i < plan.scenes.length; i++) {
      const imgPath = path.join(workDir, `scene-${i}.png`);
      await generateImage(plan.scenes[i], imgPath);
      imagePaths.push(imgPath);
    }

    pushLog("Step 4/5: Assembling final video…");
    const videoPath = path.join(workDir, "final.mp4");
    await assembleVideo({ imagePaths, audioPath, outPath: videoPath, title: plan.title });

    if (hasToken()) {
      pushLog("Step 5/5: Uploading to YouTube…");
      const result = await uploadVideo({
        filePath: videoPath,
        title: plan.title,
        description: plan.description,
        tags: plan.tags,
      });
      pushLog(`✅ Uploaded! https://youtu.be/${result.id}`);
    } else {
      pushLog("⚠️ Not connected to YouTube yet — video saved but not uploaded. Visit /auth.");
    }

    lastRun = { time: new Date().toISOString(), title: plan.title, success: true };
  } catch (err) {
    pushLog(`❌ Pipeline failed: ${err.message}`);
    lastRun = { time: new Date().toISOString(), error: err.message, success: false };
  } finally {
    isRunning = false;
  }
}

/* ── ROUTES ── */
app.get("/", (req, res) => {
  res.send(`
    <pre style="font-family:monospace;font-size:14px;line-height:1.6;padding:20px;background:#0a0a16;color:#ddd;">
AutoTube Bot — Status

YouTube connected: ${hasToken() ? "YES ✓" : "NO — visit /auth"}
Schedule: ${process.env.CRON_SCHEDULE || "0 14 * * *"} (${process.env.TIMEZONE || "server time"})
Last run: ${lastRun ? JSON.stringify(lastRun, null, 2) : "none yet"}

Routes:
  GET  /auth          - connect your YouTube channel (one time)
  GET  /run-now        - trigger the pipeline immediately
  GET  /logs           - view recent activity

${log.slice(-30).join("\n")}
    </pre>
  `);
});

app.get("/auth", (req, res) => {
  if (hasToken()) {
    return res.send("Already connected to YouTube. Delete data/token.json to reconnect.");
  }
  res.redirect(getAuthUrl());
});

app.get("/auth/callback", async (req, res) => {
  try {
    await saveTokenFromCode(req.query.code);
    res.send("✅ YouTube connected! You can close this tab. The bot will now post automatically.");
  } catch (err) {
    res.status(500).send("Auth failed: " + err.message);
  }
});

app.get("/run-now", async (req, res) => {
  res.send("Pipeline started. Check /logs for progress.");
  runPipeline();
});

app.get("/logs", (req, res) => {
  res.type("text/plain").send(log.join("\n") || "No activity yet.");
});

/* ── SCHEDULER ── */
const schedule = process.env.CRON_SCHEDULE || "0 14 * * *";
cron.schedule(schedule, () => {
  pushLog(`Cron triggered (${schedule}) — starting pipeline.`);
  runPipeline();
}, { timezone: process.env.TIMEZONE || "UTC" });

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  pushLog(`AutoTube bot running on port ${PORT}. Schedule: ${schedule}`);
});
