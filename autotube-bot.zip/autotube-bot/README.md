# AutoTube Bot — Deployment Guide

This is the server that actually does the work: research → script → voice →
video → upload, on a schedule, using YouTube's official API. No bypassing,
no bot-detection evasion — this is the same upload endpoint every legitimate
scheduling tool uses, so your channel stays in good standing.

## 1. Push this folder to GitHub

```
cd autotube-bot
git init
git add .
git commit -m "AutoTube bot"
```
Create a new repo on github.com, then:
```
git remote add origin https://github.com/YOUR_USERNAME/autotube-bot.git
git push -u origin main
```

## 2. Deploy to Railway

1. Go to https://railway.app → New Project → **Deploy from GitHub repo**
2. Select your `autotube-bot` repo
3. Railway auto-detects Node.js and builds it

## 3. Add a persistent volume (important)

Without this, your YouTube login is wiped every time Railway redeploys.

1. In your Railway project → your service → **Volumes** tab
2. Add a volume, mount path: `/app/data`
3. Set the env var `DATA_DIR=/app/data` (see step 4)

## 4. Set environment variables

In Railway → your service → **Variables**, add everything from `.env.example`:

| Variable | Where to get it |
|---|---|
| `ANTHROPIC_API_KEY` | console.anthropic.com → API Keys |
| `OPENAI_API_KEY` | platform.openai.com → API Keys (used for voice + images) |
| `YOUTUBE_CLIENT_ID` / `YOUTUBE_CLIENT_SECRET` | From the Setup tab in your dashboard (Google Cloud Console credentials) |
| `YOUTUBE_REDIRECT_URI` | `https://YOUR-RAILWAY-URL.up.railway.app/auth/callback` — copy your real Railway URL once deployed |
| `CRON_SCHEDULE` | e.g. `0 14 * * *` = every day at 2 PM |
| `DATA_DIR` | `/app/data` (matches the volume above) |

After setting `YOUTUBE_REDIRECT_URI`, go back to Google Cloud Console →
Credentials → your OAuth client → add that exact URL under "Authorized
redirect URIs" → Save.

## 5. Connect your YouTube channel (one time)

Visit `https://YOUR-RAILWAY-URL.up.railway.app/auth`, sign in with the
Google account that owns your channel, approve the permissions. That's it —
the bot stores a refresh token and never asks again (as long as the volume
persists).

> Note: while your Google Cloud OAuth app is in "Testing" mode, Google
> requires re-approval every 7 days. To remove that limit permanently,
> submit the app for verification: Google Cloud Console → OAuth consent
> screen → Publish App → Submit for verification. It's a form, takes a
> few days for Google to review, and is free.

## 6. Test it

Visit `https://YOUR-RAILWAY-URL.up.railway.app/run-now` to trigger one full
run immediately. Watch progress at `/logs`. If it uploads successfully,
you're live — it will now run automatically on the schedule you set.

## Costs to expect (Railway doesn't cover these)

- Anthropic API: pennies per script
- OpenAI TTS + image generation: roughly $0.10–$0.40 per video depending on length
- Railway: free tier covers light use; ~$5/mo if you scale up

## If something fails

Check `/logs` first — every step logs its own errors (bad API key, ffmpeg
issue, YouTube quota, etc.) so you can see exactly where it broke.
